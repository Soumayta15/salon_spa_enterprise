
import { stripe } from "@/lib/stripe"
import { NextResponse } from "next/server"

export async function POST(req: Request) {
  const { name, price } = await req.json()

  const session = await stripe.checkout.sessions.create({
    payment_method_types: ["card"],
    line_items: [{
      price_data: {
        currency: "inr",
        product_data: { name },
        unit_amount: price * 100,
      },
      quantity: 1
    }],
    mode: "payment",
    success_url: process.env.NEXT_PUBLIC_SITE_URL + "/dashboard",
    cancel_url: process.env.NEXT_PUBLIC_SITE_URL + "/booking"
  })

  return NextResponse.json({ url: session.url })
}
