
"use client"
import { useEffect, useState } from "react"
import { supabase } from "@/lib/supabaseClient"

export default function BookingPage() {
  const [services,setServices]=useState<any[]>([])

  useEffect(()=>{
    supabase.from("services").select("*").then(res=>setServices(res.data||[]))
  },[])

  return (
    <div style={{padding:40}}>
      <h2>Book Appointment</h2>
      {services.map(s=>(
        <div key={s.id}>{s.name} - ₹{s.price}</div>
      ))}
    </div>
  )
}
