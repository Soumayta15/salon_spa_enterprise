
export default function Home() {
  return <div style={{padding:40}}>Welcome to Salon & Spa Enterprise System</div>
}
