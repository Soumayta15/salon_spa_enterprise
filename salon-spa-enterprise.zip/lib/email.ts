
import sgMail from "@sendgrid/mail"

sgMail.setApiKey(process.env.SENDGRID_API_KEY!)

export async function sendBookingEmail(to: string) {
  await sgMail.send({
    to,
    from: "noreply@salon.com",
    subject: "Booking Confirmed",
    text: "Your appointment has been confirmed."
  })
}
